import styled from "styled-components";
export  const Usu=styled.nav`
@import url('https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400..800;1,400..800&display=swap');
        *{
            padding:0;
            margin:0;
            box-sizing:border-box;
            }
            #root{
            width:100vw;
            min-height:100vh;
            display:flex;
            flex-direction:column;
        
    }
       
        .container {
            position:absolute;
            display: flex;
            margin-top: 50px;
            font-family: 'EB Garamond';
            background-image:url(public/bg4.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            text-align: center;
            color: #000;
            width:100%;
            height:100%;
        }
        .t1 {
            position:absolute;
            font-size: 4em;
            margin-bottom: 30px;
            top: 20%;
            left: 30%;
           
        }
        .menu {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .lista{
            background-color: #00bcd4;
            color: #fff;
            padding: 10px 20px;
            margin: 30px 0;
            width: 90%;
            height: 20%;
            text-align: center;
            border-radius: 10px;
            text-decoration: none;
            font-size: 3em;
            display: flex;
            align-items: center;
            justify-content: center;
            
        }
        .i{
            color: black;
            text-decoration-line: none;
        }
        .i:hover{
            color: #00bcd4;
        }
        .menu-item i {
            margin-right: 10px;
        }
        .logo {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: #000;
            color: #fff;
            padding: 10px;
            border-radius: 50%;
        }
`