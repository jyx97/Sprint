import styled from "styled-components";
export  const CadV=styled.nav`
background-color: #f0f0f0;@import url('https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400..800;1,400..800&display=swap');

*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'EB Garamond';
}
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    
    
}
.img1{
    z-index: 0;
}

.login {
    position: absolute;
    background-color: #fff;
    padding: 30px;
    top: 20%;
    left: 40%;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
    text-align: center;
    z-index: 5;
}

.t2 {
    color: #333;
}

.mod,.placa,.ano{
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border-radius: 5px;
    border: 1px solid #ddd;
}

.cadastrar {
    background-color: #009EB5;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.cadastrar:hover {
    background-color: #009EB5;
}

.ca {
    color: #009EB5;
    text-decoration: none;
}
`