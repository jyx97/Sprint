import { StrictMode } from 'react'
import { createBrowserRouter,RouterProvider } from 'react-router-dom'
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import Agendamento from './routes/Agendamento/agendamento.tsx'
import Cadastro from './routes/Cad/cad.tsx'
import CadastroVeiculo from './routes/CadV/index.tsx'
import Error from './routes/Error/index.tsx'
import Informacao from './routes/Info/Info.tsx'
import Home from './routes/Home/Home.tsx'
import Login from './routes/Login/Login.tsx'
import MecDev from './routes/MecDev/MecDev.tsx'
import Orc from './routes/Orc/Orc.tsx'
import Orcamento from './routes/Orcamento/index.tsx'
import Perfil from './routes/Perfil/index.tsx'
import QuemSomos from './routes/QuemSomos/QuemSomos.tsx'
import Vec from './routes/Vec/index.tsx'
import Servicos from './routes/Servicos/index.tsx'
import Usuario from './routes/Usuario/index.tsx'
import Header from './routes/Header/Header.tsx'
import Rodape from './routes/Rodapé/Rodape.tsx'

const router=createBrowserRouter([{
  path: '/',
  element: <App />,
  errorElement: <Error/>,
  children:[
    {
      path: '/',
      element: (
        <>
          <Home />
        </>
      )
    },
    {
      path:'/Agendamento',
      element: <Agendamento/>
    },
    {
      path:'/Cadastro',
      element: <Cadastro/>
    },
    {
      path:'/CadastroV',
      element: <CadastroVeiculo/>
    },
    {
      path: '/Informacao',
      element: (
        <>
          <Header />
          <Informacao />
          <Rodape />
        </>
      )
    },
    {
      path:'/Login',
      element: <Login/>
    },
    {
      path:'/MecDev',
      element: <MecDev/>
    },
    {
      path:'/Orc',
      element: <Orc/>
    },
    {
      path:'/Orcamento',
      element: <Orcamento/>
    },
    {
      path:'/Perfil',
      element: <Perfil/>
    },
    {
      path: '/QuemSomos',
      element: (
        <>
          <Header />
          <QuemSomos />
        </>
      )
    },
    {
      path:'/Vec',
      element: <Vec/>
    },
    {
      path:'/Servicos',
      element: <Servicos/>
    },
    {
      path:'/Usuario',
      element: <Usuario/>
    }
  ]
}])



createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
