import { Link } from "react-router-dom"
import "../../estilos/cad.css"

function Cadastro(){
    return(
        <>
        <div className="HomeS">
                <header className="Cabecalho">
                    <h1 className="Titulo">
                        <Link className="t" to="/">HelpCar</Link>
                    </h1>
                    <nav className="Menu">
                        <ul className="links">
                            <li><Link to={'/'} className="Home">Home</Link ></li>
                            <li><Link to="/QuemSomos" className="QuemSomos">Quem somos</Link></li>
                            <li><Link to="/Informacao" className="Sobre">Sobre o site</Link></li>
                            <li><Link to="/Servicos" className="Servicos">Serviços</Link></li>
                            <li><Link to="/Login" className="Entrar">Entrar</Link></li>
                            <li><a href="https://github.com" className="github">
                                <img src="gitHub.png" width="25px" height="25px" alt="GitHub" />
                            </a></li>
                        </ul>
                    </nav>
                </header>
       <section className="cad">
        <h2 className="t2__cad">Cadastro</h2>
        <form action="/Usuario">
            <label htmlFor="nome">Digite seu nome:</label><br/>
            <input className="nome__cad"  type="text" id="nome" name="nome" required/><br/>
            <label htmlFor="email">Digite seu email:</label><br/>
            <input className="email__cad"  type="text" id="email" name="email" required/><br/>
            <label htmlFor="cpf">Digite seu cpf:</label><br/>
            <input className="cpf__cad"  type="text" maxLength={11} id="cpf" name="cpf" required/><br/>
            <label htmlFor="rg">Digite seu rg:</label><br/>
            <input className="rg__cad"  type="text" maxLength={9} id="rg" name="rg" required/><br/>
            <label htmlFor="senha">Digite sua senha:</label><br/>
            <input className="senha__cad" type="password" maxLength={6} id="senha" name="senha" required/><br/><br/>
            <label htmlFor="senha2">Digite sua senha novmente:</label><br/>
            <input className="senha2__cad" type="password"  maxLength={6} id="senha2" name="senha2" required/><br/><br/>
            <Link to={'/Usuario'}><input className="cadastrar__cad" type="submit" value="Cadastrar"/></Link>
        </form> 
        
        </section>
        <img className="img1__login" src="img1.jpg" height="100%" width="100%" alt=""></img>
        <footer className="rodape__Home">
                    <section className="organiza">
                        <section className="c">
                            <h2>Serviços</h2>
                            <p><Link className="i" to={'/Agendamento'}>Agendamentos</Link></p>
                            <p><Link className="i" to={'/Orc'}>Orçamentos</Link></p>
                            <p><Link className="i" to={'/DevMec'}>Mecanico Delivery</Link></p>
                        </section>
                        <section className="c">
                            <h2>Informações</h2>
                            <p><Link className="i" to={'/QuemSomos'}>Quem Somos</Link></p>
                            <p><Link className="i" to={'/Informacao'}>Sobre o site</Link></p>

                        </section>
                        <section className="c">
                            <h2>Funcionalidades</h2>
                            <p><Link className="i" to={''}>Chat Bot</Link></p>
                        </section>
                    </section>
                </footer>
            </div>
        </>
    )
}

export default Cadastro