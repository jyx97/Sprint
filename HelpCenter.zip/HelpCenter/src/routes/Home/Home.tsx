import { Link } from "react-router-dom";
import '../../estilos/styled.css';

function Home (){
    return (
        <div className="HomeS">
            <header className="Cabecalho">
                <h1 className="Titulo">
                    <Link className="t" to="/">HelpCar</Link>
                </h1>
                <nav className="Menu">
                    <ul className="links">
                        <li><Link to="/QuemSomos" className="QuemSomos">Quem somos</Link></li>
                        <li><Link to="/Informacao" className="Sobre">Sobre o site</Link></li>
                        <li><Link to="/Servicos" className="Servicos">Serviços</Link></li>
                        <li><Link to="/Login" className="Entrar">Entrar</Link></li>
                        <li><a href="https://github.com" className="github">
                            <img src="gitHub.png" width="25px" height="25px" alt="GitHub" />
                        </a></li>
                    </ul>
                </nav>
            </header>
            <section className="Titulos">
                <h1 className="t1">HelpCar</h1>
                <p className="p1">Site especializado em ajudar nos problemas automotivos dos nossos clientes</p>
                <Link className="bt1" to="/Informacao">
                    <button className="but">Saiba Mais</button>
                </Link>
            </section>
            <section className="Ser">
        <h2 className="t2">Serviços</h2>
        <div className="service-container">
            <div className="service-item">
                <img className="img2" src="public/img2.jfif" alt="Agendamento" />
                <h2 className="t3">Agendamentos</h2>
                <p className="p2">Agende um horário em uma mecânica para agilizar o seu tempo</p>
                <Link className="bt2" to="/Agendamento">
                    <button className="but2">Agendamentos</button>
                </Link>
            </div>
            <div className="service-item">
                <img className="img3" src="public/img3.jpg" alt="Orçamento" />
                <h2 className="t4">Orçamentos</h2>
                <p className="p3">Veja um pré-orçamento</p>
                <Link className="bt3" to="/Orc">
                    <button className="but3">Orçamentos</button>
                </Link>
            </div>
            <div className="service-item">
                <img className="img4" src="public/img4.png" alt="Delivery" />
                <h2 className="t5">Mecânico Delivery</h2>
                <p className="p4">Agora seu veículo pode ser arrumado de qualquer lugar</p>
                <Link className="bt4" to="/MecDev">
                    <button className="but4">Mecânico Delivery</button>
                </Link>
            </div>
        </div>
    </section>
            <footer className="rodape__Home">
<section className="organiza">
    <section className="c">
        <h2>Serviços</h2>
        <p><Link className="i" to={'/Agendamento'}>Agendamentos</Link></p>
        <p><Link className="i" to={'/Orc'}>Orçamentos</Link></p>
        <p><Link className="i" to={'/DevMec'}>Mecanico Delivery</Link></p>
    </section>
    <section className="c">
        <h2>Informações</h2>
        <p><Link className="i" to={'/QuemSomos'}>Quem Somos</Link></p>
        <p><Link className="i" to={'/Informacao'}>Sobre o site</Link></p>

    </section>
    <section className="c">
        <h2>Funcionalidades</h2>
        <p><Link className="i" to={''}>Chat Bot</Link></p>
    </section>
</section>
</footer>
            <img className="img1" src="public/img1.jpg" alt="Imagem de fundo" />
        </div>
    )
}

export default Home