import { Link } from "react-router-dom"
import "../../estilos/mecdev.css"

function MecDev(){
    return (
        <>
         <div className="HomeS">
                <header className="Cabecalho">
                    <h1 className="Titulo">
                        <Link className="t" to="/">HelpCar</Link>
                    </h1>
                    <nav className="Menu">
                        <ul className="links">
                            <li><Link to={'/'} className="Home">Home</Link ></li>
                            <li><Link to="/QuemSomos" className="QuemSomos">Quem somos</Link></li>
                            <li><Link to="/Informacao" className="Sobre">Sobre o site</Link></li>
                            <li><Link to="/Servicos" className="Servicos">Serviços</Link></li>
                            <li><Link to="/Login" className="Entrar">Entrar</Link></li>
                            <li><a href="https://github.com" className="github">
                                <img src="gitHub.png" width="25px" height="25px" alt="GitHub" />
                            </a></li>
                        </ul>
                    </nav>
                </header>
         <section className="login__mec">
        <h2 className="t2__mec">Mecânico Delivery</h2>
        <form action="index.html">
            <label htmlFor="end">Digite seu endereço:</label><br/>
            <input className="end__mec"  type="text" id="end" name="end" required/><br/>
            <label htmlFor="problem">Digite o problema do carro:</label><br/>
            <input className="problem__mec"  type="text" id="problem" name="problem" required/><br/>

            <label htmlFor="placa">Digite a placa do veiculo:</label><br/>
            <input className="placa__mec" type="text" maxLength={7}  id="placa" name="placa" required/><br/><br/>

            <Link to={'/'}><input className="cadastrar__mec" type="submit" value="Chamar o mecanico delivery"/></Link>
        </form> 
        
    </section>
    <img className="img1" src="img1.jpg" height="100%" width="100%" alt=""></img>
    <footer className="rodape__Home">
                    <section className="organiza">
                        <section className="c">
                            <h2>Serviços</h2>
                            <p><Link className="i" to={'/Agendamento'}>Agendamentos</Link></p>
                            <p><Link className="i" to={'/Orc'}>Orçamentos</Link></p>
                            <p><Link className="i" to={'/DevMec'}>Mecanico Delivery</Link></p>
                        </section>
                        <section className="c">
                            <h2>Informações</h2>
                            <p><Link className="i" to={'/QuemSomos'}>Quem Somos</Link></p>
                            <p><Link className="i" to={'/Informacao'}>Sobre o site</Link></p>

                        </section>
                        <section className="c">
                            <h2>Funcionalidades</h2>
                            <p><Link className="i" to={''}>Chat Bot</Link></p>
                        </section>
                    </section>
                </footer>
            </div>
        </>
    )
}

export default MecDev