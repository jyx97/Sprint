import { Link } from "react-router-dom"
import "../../estilos/login.css"

function Login(){
    return(
        <>
         <div className="HomeS">
                <header className="Cabecalho">
                    <h1 className="Titulo">
                        <Link className="t" to="/">HelpCar</Link>
                    </h1>
                    <nav className="Menu">
                        <ul className="links">
                            <li><Link to={'/'} className="Home">Home</Link ></li>
                            <li><Link to="/QuemSomos" className="QuemSomos">Quem somos</Link></li>
                            <li><Link to="/Informacao" className="Sobre">Sobre o site</Link></li>
                            <li><Link to="/Servicos" className="Servicos">Serviços</Link></li>
                            <li><Link to="/Login" className="Entrar">Entrar</Link></li>
                            <li><a href="https://github.com" className="github">
                                <img src="gitHub.png" width="25px" height="25px" alt="GitHub" />
                            </a></li>
                        </ul>
                    </nav>
                </header>
         <section className="login">
        <h2 className="t2__login">Login</h2>
        <form action={'/Usuario'}>
            <label htmlFor="email">Digite seu email:</label><br/>
            <input className="email__login"  type="text" id="email" name="email" required/><br/>

            <label htmlFor="senha">Digite sua senha:</label><br/>
            <input className="senha__login" type="password" maxLength={6} id="senha" name="senha" required/><br/><br/>

            <Link to={'/Usuario'}><input className="cadastrar__login" type="submit" value="Logar"/></Link>
        </form> 
        <p>Não tem uma conta? <Link className="ca__login" to={'/Cadastro'}>Clique aqui!</Link></p>
    </section>
    <img className="img1__login" src="img1.jpg" height="100%" width="100%" alt=""></img>
    <footer className="rodape__Home">
                    <section className="organiza">
                        <section className="c">
                            <h2>Serviços</h2>
                            <p><Link className="i" to={'/Agendamento'}>Agendamentos</Link></p>
                            <p><Link className="i" to={'/Orc'}>Orçamentos</Link></p>
                            <p><Link className="i" to={'/DevMec'}>Mecanico Delivery</Link></p>
                        </section>
                        <section className="c">
                            <h2>Informações</h2>
                            <p><Link className="i" to={'/QuemSomos'}>Quem Somos</Link></p>
                            <p><Link className="i" to={'/Informacao'}>Sobre o site</Link></p>

                        </section>
                        <section className="c">
                            <h2>Funcionalidades</h2>
                            <p><Link className="i" to={''}>Chat Bot</Link></p>
                        </section>
                    </section>
                </footer>
            </div>
        </>
    )
}

export default Login