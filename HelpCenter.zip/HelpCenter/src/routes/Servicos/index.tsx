import { Usu } from "../../estilos/usu"
export default function Servicos(){
    return(
        <Usu>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></link>
            <section className="logo">
        <i className="fas fa-dollar-sign"></i>
    </section>
    <section className="container">
        <section className="t1">
            <h1>Seus Servicos</h1>
        </section>
    </section>         
        </Usu>
    )
}