import { Link } from "react-router-dom"
import { CadV } from "../../estilos/cadV"

export default function CadastroVeiculo(){
    return(
        <CadV>
            <section className="login">
        <h2 className="t2">Cadastro Veiculo</h2>
        <form action="'/Vec'">
            <label htmlFor="placa">Digite a placa do seu veiculo:</label><br/>
            <input className="placa"  type="text" maxLength={7} id="placa" name="placa" required/><br/>
            <label htmlFor="ano">Digite o ano do seu veiculo:</label><br/>
            <input className="ano"  type="text" maxLength={4} id="ano" name="ano" required/><br/>
            <label htmlFor="mod">Digite o modelo:</label><br/>
            <input className="mod"  type="text"  id="mod" name="mod" required/><br/>
            <Link to={'/Vec'}><input className="cadastrar" type="submit" value="Cadastrar Veiculo"/></Link>
        </form> 
        
    </section>
    <img className="img1" src="img1.jpg" height="100%" width="100%" alt=""/>
            
        </CadV>
    )
}