import { Link } from "react-router-dom"
import { Usu } from "../../estilos/usu"
export default function Vec(){
    return(
        <Usu>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"></link>
            <section className="logo">
        <i className="fas fa-dollar-sign"></i>
    </section>
    <section className="container">
        <section className="t1">
            <h1>Seus Veiculos</h1>
            <Link className="i" to={'/CadastroV'}>Adicionar veiculo</Link>
        </section>
    </section>          
        </Usu>
    )
}