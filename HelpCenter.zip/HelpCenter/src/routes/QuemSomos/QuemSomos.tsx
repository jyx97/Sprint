import { Link } from "react-router-dom";
import "../../estilos/quemsomos.css"

function QuemSomos() {
    return (
        <>
            <div className="about__content">
                <section className="Titulo__about">
                    <h1 className="t1__about">Quem Somos</h1>
                </section>
                <section className="Infos__about">
                    <p className="p5__about">Somos uma empresa em  que visa ajudar os motoristas a agilizarem o seu tempo caso tenham problemas em seus veículos a partir da utilização de um chat bot.</p>
                </section>
                <section id="Int" className="Int">
                    <h1 className="t2__about">Integrantes</h1>
                    <img className="img3__about" src="julia.enc" width="189px" height="329px" alt="Orcamento" />
                    <h2 className="t4__about">Júlia Soares Farias dos Santos</h2>
                    <p className="p3__about">RM:554609</p>
                    <a className="g2__about" href="https://github.com/jyx97">Git Hub</a>
                    <img className="img4__about" src="hellen.jfif" width="189px" height="329px" alt="Delivery" />
                    <h2 className="t5__about">Hellen Marinho Cordeiro</h2>
                    <p className="p4__about">RM:558841</p>
                    <a className="g3__about" href="https://github.com/hmarinhoo">Git Hub</a>
                </section>
                <footer className="rodape__about">
<section className="organiza">
    <section className="c">
        <h2>Serviços</h2>
        <p><Link className="i" to={'/Agendamento'}>Agendamentos</Link></p>
        <p><Link className="i" to={'/Orc'}>Orçamentos</Link></p>
        <p><Link className="i" to={'/DevMec'}>Mecanico Delivery</Link></p>
    </section>
    <section className="c">
        <h2>Informações</h2>
        <p><Link className="i" to={'/QuemSomos'}>Quem Somos</Link></p>
        <p><Link className="i" to={'/Informacao'}>Sobre o site</Link></p>

    </section>
    <section className="c">
        <h2>Funcionalidades</h2>
        <p><Link className="i" to={''}>Chat Bot</Link></p>
    </section>
</section>
</footer>
                <img className="img1__about" src="img1.jpg" height="100%" width="100%" alt="" />
                <img className="bg2__about" src="bg2.jpg" height="100%" width="100%" alt="" />
            </div>

        </>
    )

}

export default QuemSomos