import { Link } from "react-router-dom"
import "../../estilos/info.css"

function Informacao(){
    return (   
        <>
        <section className="Titulo__Info">
        <img className="img1__Info" src="img1.jpg" height="100%" width="100%"  alt="" />
            <h1 className="t1__info">Visão Geral do site</h1>
        </section>
        <section className="InfoGeral">
            <p className="p5__Info">Nós somos uma empresa  que visa ajudar os motoristas a agilizarem o seu tempo caso tenham problemas em seus veículos a partir da utilização de um chat bot.</p>
        </section>
       
        <section className="Info2">
            <h1 className="t2__info">Agendamento</h1>
            <p className="p6__info">Nosso agendameno é feito de forma rápida e simples  apenas fazendo perguntas e escolhendo um horário ideal para o cliente e que se encaixe com a agenda de serviços da oficina mecânica escolhida.
                Caso o usuário não saiba em qual oficina ir,ajudamos a escolher a partir da situação do cliente e o ajudando a escolher uma mecânica ideal ao problema e a localização do usuário.</p>
            <Link className="b1__info" to={'/Agendamento'}><button className="but1__info">Faça seu agendamento aqui!</button></Link >
        </section>
       
        <section className="Info3">

            <h1 className="t3__info">Orçamentos</h1>
            <p className="p7__info">O orçamento é feito de forma rápida e com perguntas voltadas ao problema que o veículo do usuário está enfrentando e calculamos um orçamento médio para otimizar o tempo do cliente e informá-lo o valor que precisará sser gasto por ele.
                Além disso,possibilitamos,que caso o orçamento não entre nas condições do cliente, calcular outros valores mais em conta à situação.</p>
            <Link className="b2__info" to={'/Orc'}><button className="but2__info">Faça seu orçamento aqui!</button></Link >
        </section>
        <section className="Info4">
            <h1 className="t4__info">Mecânico Delivery</h1>
            <p className="p8__info">Nossa função aqui  é ajudar nossos clientes de qualquer lugar,caso o veículo não consiga se locomover para uma oficina, temos essa funcionalidade para falarmos com a mecânica mais próxima para levar um mecanico até o local que o usuário se localiza.
                Caso o problema do usuário precise de um guincho,ele será chamado e ,caso o cliente não esteja em sua residência,proporcionaremos uma opção que chame um motorista que o leve à sua residência.</p>
            <Link className="b3__info" to={'/MecDev'}><button className="but3__info">Peça um Mecânico Delivery!</button></Link >
        </section>
        <section className="Info5">
            <h1 className="t5__info">Chat Bot</h1>
            <p className="p9__info">A função do chat bot é ajudar com qualquer problema automotivo dos usuários fazendo um auto diagnóstico para informar os problemas ao usuário.Além disso,junta as outras funcionalidades citadas a cima para assim solucionar ao máximo os problemas dos clientes.</p>
            <Link className="b4__info" to={''}><button className="but4__info">Fale com o chatbot!</button></Link >
        </section>
        <img className="bg2__info" src="bg2.jpg" height="100%" width="100%" alt="" />
        
     
        </>

)
}

export default Informacao;