import { Link } from "react-router-dom"
import "../../estilos/age.css"

function Agendamento() {
    return (
        <>
            <div className="HomeS">
                <header className="Cabecalho">
                    <h1 className="Titulo">
                        <Link className="t" to="/">HelpCar</Link>
                    </h1>
                    <nav className="Menu">
                        <ul className="links">
                            <li><Link to={'/'} className="Home">Home</Link ></li>
                            <li><Link to="/QuemSomos" className="QuemSomos">Quem somos</Link></li>
                            <li><Link to="/Informacao" className="Sobre">Sobre o site</Link></li>
                            <li><Link to="/Servicos" className="Servicos">Serviços</Link></li>
                            <li><Link to="/Login" className="Entrar">Entrar</Link></li>
                            <li><a href="https://github.com" className="github">
                                <img src="gitHub.png" width="25px" height="25px" alt="GitHub" />
                            </a></li>
                        </ul>
                    </nav>
                </header>
                <section className="login__agendamento">
                    <h2 className="t2__agendamento">Agendamento</h2>
                    <form action="/">
                        <label htmlFor="data">Digite a data do agendamento:</label><br />
                        <input className="data__agendamento" type="date" id="data" name="data" required /><br />

                        <label htmlFor="local">Digite o local de agendamento:</label><br />
                        <input className="local__agendamento" type="text" id="local" name="local" required /><br /><br />

                        <Link to={'/'}><input className="cadastrar__agendamento" type="submit" value="Agendar" /></Link>
                    </form>

                </section>
                <img className="img1__agendamento" src="img1.jpg" height="100%" width="100%" alt=""></img>
                <footer className="rodape__Home">
                    <section className="organiza">
                        <section className="c">
                            <h2>Serviços</h2>
                            <p><Link className="i" to={'/Agendamento'}>Agendamentos</Link></p>
                            <p><Link className="i" to={'/Orc'}>Orçamentos</Link></p>
                            <p><Link className="i" to={'/DevMec'}>Mecanico Delivery</Link></p>
                        </section>
                        <section className="c">
                            <h2>Informações</h2>
                            <p><Link className="i" to={'/QuemSomos'}>Quem Somos</Link></p>
                            <p><Link className="i" to={'/Informacao'}>Sobre o site</Link></p>

                        </section>
                        <section className="c">
                            <h2>Funcionalidades</h2>
                            <p><Link className="i" to={''}>Chat Bot</Link></p>
                        </section>
                    </section>
                </footer>
            </div>
        </>
    )
}

export default Agendamento