import { Link } from 'react-router-dom'
import "../../estilos/rodape.css"

function Rodape() {
return (
<footer className="rodape">
<section className="organiza">
    <section className="c">
        <h2>Serviços</h2>
        <p><Link className="i" to={'/Agendamento'}>Agendamentos</Link></p>
        <p><Link className="i" to={'/Orc'}>Orçamentos</Link></p>
        <p><Link className="i" to={'/DevMec'}>Mecanico Delivery</Link></p>
    </section>
    <section className="c">
        <h2>Informações</h2>
        <p><Link className="i" to={'/QuemSomos'}>Quem Somos</Link></p>
        <p><Link className="i" to={'/Informacao'}>Sobre o site</Link></p>

    </section>
    <section className="c">
        <h2>Funcionalidades</h2>
        <p><Link className="i" to={''}>Chat Bot</Link></p>
    </section>
</section>
</footer>
)

}

export default Rodape