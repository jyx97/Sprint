
export default function Error(){
    return(
        <>
            <div className="E">
                <h1>Infelizmente a página não pode ser encontrada</h1>
                <img className="ImgErro" src="public/erro.jpg" alt="" />
            </div>
        </>
    )
}